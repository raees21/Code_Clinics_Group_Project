import unittest


class TestAcceptance(unittest.TestCase):

    def test_one(self):
        self.assertTrue(True)


if __name__ == '__main__':
    unittest.main()

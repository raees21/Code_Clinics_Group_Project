events = ['Hello', 'How', 'are', 'you']

for i, event in enumerate(events):
    print(i, event)
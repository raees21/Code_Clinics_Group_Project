# GoogleCalendarManager
Easily check and modify your Google Calendar using Google Calendar API. 

## Implementation

Language version : Python 3.6. <br />
Operating System : MacOS High Sierra.

## Getting Started

### Google Calendar API

Start by following the steps on Google Calendar API: <br />
  https://developers.google.com/calendar/quickstart/python

### Libraries

Install the set of dependencies : <br />
```
pip install -r requirements.txt
```

## Authors

Alexandra Benamar
